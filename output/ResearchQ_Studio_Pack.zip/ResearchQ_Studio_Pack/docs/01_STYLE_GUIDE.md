# 01 · Style guide (ringkas). Spesifikasi lengkap: `09_DEFAULT_STYLE_V4.md`

## Brand & tipografi
- Brand: TikTok/IG **@researchq.id** · YouTube **NotYourLecture** (brand di video YouTube = "NotYourLecture"). Watermark "ResearchQ●" kiri bawah di video vertikal.
- Font: **Plus Jakarta Sans 800** (judul, subtitle, angka bagian) · **Inter** (isi kartu, label). Embed base64 (Google Fonts diblokir di sandbox). Instrument Serif / JetBrains Mono / Anton tersedia di `assets/fonts/` untuk thumbnail & YouTube.
- Warna tema latar: light `#F6F7FB` · cream `#F2EFE6` · dark navy · blue · orange (lihat doc 09). Aksen: oranye `#FF9F43`/`#E8711A`, kuning `#FFD166`, cyan `#5CC8FF`.
- Kartu rapi dengan kotak terukur. **Jangan lingkaran/coretan tangan berantakan** (ditolak). **Tanpa label HUD "// 01" atau penghitung "1/3"** (ditolak).

## Zona aman & layout (vertikal 1080x1920)
- Konten penting x 72-1008, y 190-1540. Subtitle y ±1050-1250 (lihat doc 09).
- Jangan sisakan area kosong besar: isi dengan mockup relevan (jendela chat, tabel output SPSS/SmartPLS, diagram jalur, kartu checklist, kutipan artikel + highlight). Jangan tutup wajah maskot dengan kartu; maskot tidak boleh terpotong tepi layar.
- Struktur 40-60 dtk: hook spesifik 3-5 kata (0-3 dtk) → janji → 3-4 poin (tiap poin: latar/tema baru) → ringkasan 1 layar ±3 dtk → CTA. CTA soft-sell ("Komen KATA, nanti aku kirim link-nya"; tanpa harga di layar). Kartu penutup: logo TikTok, Instagram, YouTube + handle, muncul satu per satu, tahan ≥ 2 dtk (logo hanya dari `assets/logos`).

## Maskot (talking head)
- Karakter user: kacamata, rambut keriting hitam, kemeja navy. **Jangan menggambar ulang, mengubah gaya, atau membuat pose baru**; hanya PNG yang disediakan. Pose baru harus dari user.
- 9 pose (`assets/mascot/MASCOT_SHEET_9_poses.png`): 5 dengan meja (`m_open, m_thumb, m_think, m_point, m_warn`) dan 4 setengah badan (`n_present, n_idea, n_shrug, n_wink`). Ganti pose di momen bermakna: think = pertanyaan, point = penekanan, thumb/wink = saran/CTA, warn = kesalahan/mitos, shrug = "tergantung".
- Lip-sync: sprite mulut dipotong dari pose, skala vertikalnya mengikuti kenyaringan VO (`code/engine/lipdata.py`, 60 fps). Bukaan minimum 0.13 (0.30 untuk `m_think`, 0.22 untuk `m_warn`).
- Maskot **bergerak** (framing berubah, napas, bounce saat ganti pose), tidak diam di pojok. Framing: BIG [540,1560,1.22] (hook/CTA), SIDE [830,1690,.96] (penekanan), MID [700,1640,1.06], stiker STK [880,1770,.6]. Titik jangkar mulut `MA0={x:831,y:1668}`.
- Komposisi 60% grafis / 25% talking head / 15% stiker + branding, latar berganti per adegan, aksen Σ, buka-artikel + kamera zoom: **doc 09**.

## YouTube landscape (1920x1080, format terpisah)
Kartu judul "MISTAKE 0X", kartu mitos + stempel, kartu sumber dengan sampul buku, kutipan dengan kotak highlight, kartu "Do this instead", recap grid, end card "SUBSCRIBE TO NOT YOUR LECTURE". Subtitle karaoke EN + baris Indonesia di bawah, cue per frasa (≤ ~60 karakter). Detail: `03_WORKFLOW_YOUTUBE.md`.
