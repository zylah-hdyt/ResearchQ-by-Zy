# Style guide (what "our" videos look like)

## Look
- Palette tokens: `--bg:#F2EFE9 --paper:#FBFAF7 --ink:#1B1A18 --muted:#8C877E --faint:#CBC5BA --line:#E3DED5 --acc:#EE6A1F --accl:#FBE3D2 --dk:#141311`. Dark scenes use `#141311` with text `#F2EFE9`; accent stays orange.
- Fonts: **Plus Jakarta Sans 800** (headlines, tight letter-spacing -0.035em) · **Instrument Serif italic** (ONE emphasis word, larger) · **JetBrains Mono 500** (small labels, handles) · **Inter** (body) · **Anton** (thumbnails/covers). Embed as base64 (Google Fonts is blocked in sandboxes).
- Cards: paper `#FBFAF7`, radius 22px, soft warm shadow. Subtle paper + grain texture (`mix-blend-mode:multiply`, opacity 0.06-0.10).
- Backgrounds change per scene (cream / soft orange blobs / dots / dark) to break the pattern every 6-10 s. Circle-wipe transitions are fine, but outlines must be clean, measured boxes. **Never messy hand-drawn loops** (rejected).
- **No "// 01" HUD labels, no counters like 1/3** (rejected for the later videos).

## Captions (vertical)
- **Kinetic captions**: short phrase groups, each word enters with a different motion (slam, slide, scale, mask-reveal), key word bigger / serif-italic orange. Lives in `#kin` (left 50, top 215, 980 x 370).
- Max ~8 words per screen; do not duplicate the whole voice-over as text.
- Keep fun, spoken Indonesian (casual, simple). Hard technical words get a one-line plain explanation on screen.

## Layout and safe zone
- Safe zone for important content: x 72-1008, y 190-1540 (check script flags anything outside x 60-1020, y 180-1560).
- Brand "ResearchQ" + orange dot sits bottom-left on TikTok videos; mascot bottom-right.
- **Don't leave big empty areas**: fill with relevant mock-ups (chat window, SPSS/SmartPLS output tables, path diagram, checklist cards, book excerpt with highlight boxes), not decoration.
- Never cover the mascot's face with cards. Never let the mascot clip at the screen edge (mascot.js clamps `ov=lf+wd-1068`).

## Mascot (talking head)
- The user's character: glasses, curly black hair, navy shirt. **Never redraw, restyle or invent new poses**; only use the supplied PNGs. New poses must come from the user.
- 9 poses (see `assets/mascot/MASCOT_SHEET_9_poses.png`): 5 with desk (`m_open, m_thumb, m_think, m_point, m_warn`) and 4 half-body (`n_present, n_idea, n_shrug, n_wink`).
- Switch pose at meaningful moments (every sentence or two): warn on myths/mistakes, think on questions, thumb on advice, wink/point for CTA.
- Lip-sync: mouth sprite is cut from the pose and the face is inpainted; each frame the sprite is scaled vertically from the voice-over loudness (see docs/02 and `code/engine/lipdata.py`). Min openness 0.13 (0.30 for `m_think`, 0.22 for `m_warn`).
- Anchor point of the mouth on screen: `MA={x:831,y:1668}` (vertical). Each pose is scaled `s` (see `mouth.json`) so faces have the same size.

## Typical vertical structure (40 s)
Hook (0-3 s, specific, 3-5 words big) → promise → 3-4 points (new background + new pose each) → one-screen recap held ~3 s → CTA.
CTA is soft-sell: "Komen EBOOK dan gue kirim link" (no price on screen). End card: row of TikTok, Instagram, YouTube logos with handles, popping in one by one, held at least 2 s.

## YouTube long-form (landscape)
Title cards "MISTAKE 0X", myth card with strike line + "AVOID" stamp at the bottom edge, source card with the book cover, excerpt cards full content width with highlight boxes, "Do this instead" card, recap grid, end card "SUBSCRIBE TO NOT YOUR LECTURE" with logo pills. English karaoke subtitle + Indonesian line below, phrase-level cues (one phrase per cue, up to ~60 chars), mascot clamp at x=1905.
