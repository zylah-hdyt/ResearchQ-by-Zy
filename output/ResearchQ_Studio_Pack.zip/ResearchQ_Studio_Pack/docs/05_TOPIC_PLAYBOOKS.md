# Topic playbooks (reuse the same engine, swap the "world")

For every topic: the mascot talks, the screen shows a realistic MOCK-UP of the thing being discussed, one idea per scene. Keep facts correct, add a small source on screen for technical claims, label made-up numbers "*ilustrasi".

## 1. Claude AI for research (soft-sell the user's Claude skills)
- Mock-ups: chat window (user bubble + answer), a "Skills" list/cards, file drop, before/after text, a progress bar, a checklist of what Claude did. Claude logo only from a file the user uploads (none in this pack yet).
- Angles that fit: "stop copy-paste prompts, give Claude a skill", workflow demos (judul → kuesioner → analisis → narasi), safe use of AI (verify citations, disclose AI use, do not fabricate data), what AI cannot do.
- The user's skills (already in their Claude account, can be named in CTA): AI detection reducer, judul generator, kuesioner builder, Bab 4 writer, SmartPLS doctor, SPSS doctor, journal matcher, abstract master, etc. CTA = "Komen [KATA] dan gue kirim link" (comment-to-DM funnel); no price/promo on screen unless the user gives a final number.
- Accuracy: do not claim guaranteed pass of AI detectors or Turnitin; talk about "reduce AI-sounding patterns" and academic integrity.
- Visual style: UI-mock-up dense (style A) + kinetic captions; orange accent; end card with 3 social logos and "Dibangun di atas Claude Skills" when relevant.

## 2. SPSS
- Mock-ups: Data View / Variable View grid, Output Viewer tables (Model Summary, ANOVA, Coefficients, Reliability Statistics), normality plots, an error dialog, step-by-step menu path (Analyze → Regression → Linear ...).
- Angles: which test for which question, how to read ONE table in 10 s, common mistakes (normality of residuals not variables, multicollinearity VIF, Likert scale as interval), "what the number means" cards with thresholds and sources.
- Do not promote cracked/illegal software or license workarounds.
- Numbers on screen are *ilustrasi unless taken from a source.

## 3. SmartPLS / PLS-SEM
- Mock-ups: path diagram (circles = latent variables, rectangles = indicators, arrows with coefficients), outer loadings table, HTMT matrix, bootstrapping results with t-values / p-values / CI, R² bars.
- Source of truth used so far: Hair, Hult, Ringle, Sarstedt (2022), *A Primer on Partial Least Squares Structural Equation Modeling (PLS-SEM)*, 3rd ed. Show book cover + page excerpt with highlight boxes (`code/engine/excerpt.py`, pdfplumber word boxes). The user must upload the PDF again; never redistribute it.
- Already covered (don't repeat unless asked): simultaneous F-test is not for PLS-SEM, GoF, small-sample myth (inverse square root method; ten-times rule only rough), Fornell-Larcker vs HTMT (<0.90, <0.85), Sobel vs bootstrapping, reliability >0.95 redundant, one R² cutoff. Ideas left: history of PLS, definitions (formative vs reflective, composite vs common factor), PLSpredict, measurement invariance (MICOM), moderation, higher-order constructs, reporting checklist.
- Satire angle ("dosen minta uji simultan di PLS-SEM") worked well when it also EDUCATES (explain that "simultan" is a general word, then what to report instead).

## 4. Penelitian umum (metodologi)
- Mock-ups: research funnel / pyramid, flow of a research design, population-sample diagrams, table of sampling techniques, questionnaire page, literature matrix, journal quartile badges.
- Angles used: Pedoman kampus, Teknik ATM (amati-tiru-modifikasi), Piramida Terbalik (writing structure), Apa itu Fenomena, populasi & sampel, "perjalanan satu jawaban" (script PDFs in `docs/`).
- Keep language simple: define the term, give a concrete example, then the rule. Avoid repeating "sidang" in every script.

## Format cheat sheet
| format | length | structure |
|---|---|---|
| TikTok/Reels | 30 s | hook 0-2 · promise 2-5 · 3 points · recap 23-27 · CTA 27-30 |
| TikTok/Reels | 40-60 s | hook 0-3 · promise 3-8 · 4-5 points with re-hook ~20 s and ~38 s · recap 48-54 · CTA 54-60 |
| YouTube | ~5 min | intro 0:00 · 7 numbered sections ~30 s each · recap · end card; EN VO + EN/ID subs |
