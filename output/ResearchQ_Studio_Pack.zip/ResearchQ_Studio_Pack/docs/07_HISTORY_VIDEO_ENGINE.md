# Video sejarah "The History of SEM" (YouTube 16:9, 3:20): engine dan PELAJARAN

Source lengkap: `code/templates/history_world_map_camera/` (template.html, script.py, subs.py, audio.py, run3.sh, render3.sh).

## Apa yang dibangun
- **Dunia besar + kamera.** Semua adegan ditaruh di satu "peta" (`#world`, 26.000 px lebar); kamera bergerak antar stasiun lewat keyframe `kf(t,x,y,zoom)`, interpolasi zoom dalam log, whip-pan dengan motion blur arah, roll kecil, parallax angka tahun raksasa di lapisan belakang.
- Chapter card sinematik, ticker tahun, garis waktu, rail software, zoom-out ke seluruh peta di penutup, end card.
- Subtitle kinetic Indonesia per frasa (4 gaya gerak bergantian, kata kunci ditandai `*kata*`).
- Suara: ZipVoice klon dari referensi; alignment kata dengan anchor (lihat docs/03). SFX: `audio.py` membaca `work/events.json` yang diekspor halaman (`SFXLIST()`), plus whoosh otomatis dari kecepatan kamera.
- Alur kerja: `script.py` → `subs.py` → `zv_build.py` → `run3.sh` (align, mix, lip, build, events, audio) → `snap.js` (contact sheet) → `render3.sh`.

## PENILAIAN USER atas hasilnya (jangan diulang)
1. **Animasi kurang terasa "story / history".** Hasilnya masih berupa kartu/slide yang bergerak, bukan penceritaan visual. Untuk sejarah: satu adegan per momen (tokoh, tempat, dokumen, objek, perubahan era), transisi waktu yang terasa (kertas/arsip/tinta, tanggal berganti), bukan panel UI.
2. **Suara AI kurang cocok untuk storytelling** (datar, tempo tidak naratif). Tes suara dulu; bila tidak cocok tawarkan user merekam sendiri atau voice lain.
3. **SFX "ngawur":** pop/ding/whoosh otomatis tidak cocok dengan cerita sejarah. Gunakan ambience halus, kertas, tinta, lonceng, tick jam; jadwalkan manual per adegan dan beri alasannya.
4. **Teks Indonesia terasa terjemahan, kaku.** Jangan menerjemahkan subtitle dari bahasa Inggris. Tulis ulang sebagai bahasa Indonesia lisan yang natural: kalimat pendek, satu ide per potongan, tanpa istilah akademis yang berbelit ("memaksimalkan varians yang dijelaskan", "kerangka", dst).
5. **Jangan membuat wajah tokoh nyata dengan AI** untuk thumbnail/visual; pakai siluet atau foto domain publik yang sumbernya jelas. User tidak mau konten tentang marmut untuk versi 50 detik.
6. Judul: samakan bahasa judul dan thumbnail; jangan percaya skor vidIQ begitu saja; judul harus menjanjikan hal yang benar-benar ada di video.

## Yang TIDAK boleh dilakukan lagi
Kirim video penuh tanpa sampel; menilai animasi hanya dari frame diam; menjadwalkan SFX otomatis tanpa memikirkan genre; mengklaim audio beres padahal belum didengar.
