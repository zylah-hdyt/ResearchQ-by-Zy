# Rules and lessons learned (do not repeat these mistakes)

## Hard rules
1. **Logos only from files the user gave** (TikTok, Instagram, YouTube are in `assets/logos`). If a logo is missing (Claude, ResearchQ), ask. Never redraw a brand logo.
2. **Mascot: do not create or modify.** Use the supplied poses; ask the user for new poses.
3. **Voice**: clone only the user's own voice / with permission; mark YouTube videos as synthetic content.
4. **Copyright**: do not promote or redistribute bundles of other people's books/PDFs (the 25k e-book bundle with Hair's book was declined). The "Komen EBOOK" CTA must lead to an ORIGINAL ResearchQ/NotYourLecture guide. Quote books only briefly with source on screen.
5. **Facts**: technical claims need a source on screen; invented numbers are labelled "*ilustrasi". Do not guarantee outcomes (passing detectors, sidang, publication).
6. Soft sell: no price/promo unless a final figure is given. Pure education videos mention no product.
7. Always render a contact sheet first and inspect it; say honestly when audio was not listened to.

## Feedback the user gave (fixes you must keep)
- Messy hand-drawn circle outlines in scenes → use neat measured boxes.
- A harsh SFX at the start was rejected → bell / pop / ding only.
- Captions: want **kinetic**; no "// 01" labels; backgrounds should differ per scene; visuals "lebih bagus".
- Mascot cut off at the screen edge / too much empty space → clamp + fill with mock-ups.
- Unclear, hard-to-hear VO segments must be cut or re-done.
- Hook must be specific and make sense (do not invent things like "uji simultan di SmartPLS" as if it exists); language simple and easy to follow; explain terms (e.g. "simultan" is general Indonesian/KBBI, not only statistics); stop saying "sidang" in every script.
- YouTube VO sounded robotic → paragraph synthesis + reference voice; subtitles untidy → phrase cues; brand on YouTube = NotYourLecture; acronyms must not be spelled letter by letter.
- Title and thumbnail in the same language; add "Sub Indo" when VO is English and title is Indonesian.

## Why the viral reference worked (from the analysis of the user's best video + analytics)
Talking head + fast mock-up visuals, specific hook in the first 2 s, one clear takeaway, comment-keyword CTA. The user likes the talking head; revise hook style and ideas, not the format.

## Known small issues
- TikTok/IG handle on the end card = @researchq.id for both (confirm if it changes).
- "a" is occasionally read as "ay" by the English voice; check after synthesis.
- ZipVoice may drop first words if prompt text ≠ prompt audio.
- GitHub model downloads can 504: retry.

## Disk / render hygiene
Frames are huge: delete finished frame folders by absolute path; check `df -h` before starting; run 4 render workers in the background and poll file count (never `pgrep -f`).
