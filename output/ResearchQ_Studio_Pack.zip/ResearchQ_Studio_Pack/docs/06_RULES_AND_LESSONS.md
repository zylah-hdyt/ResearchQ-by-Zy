# Rules and lessons learned (do not repeat these mistakes)

## Hard rules
1. **Logos only from files the user gave** (TikTok, Instagram, YouTube are in `assets/logos`). If a logo is missing (Claude, ResearchQ), ask. Never redraw a brand logo.
2. **Mascot: do not create or modify.** Use the supplied poses; ask the user for new poses.
3. **Voice**: clone only the user's own voice / with permission; mark YouTube videos as synthetic content.
4. **Copyright**: do not promote or redistribute bundles of other people's books/PDFs (the 25k e-book bundle with Hair's book was declined). The "Komen EBOOK" CTA must lead to an ORIGINAL ResearchQ/NotYourLecture guide. Quote books only briefly with source on screen.
5. **Facts**: technical claims need a source on screen; invented numbers are labelled "*ilustrasi". Do not guarantee outcomes (passing detectors, sidang, publication).
6. Soft sell: no price/promo unless a final figure is given. Pure education videos mention no product.
7. Always render a contact sheet first and inspect it; say honestly when audio was not listened to.

## Feedback the user gave (fixes you must keep)
- Messy hand-drawn circle outlines in scenes → use neat measured boxes.
- SFX keras di awal dan bunyi "tombol salah" ditolak → pop / klik / swoosh lembut / ding saja.
- Captions: want **kinetic**; no "// 01" labels; backgrounds should differ per scene; visuals "lebih bagus".
- Mascot cut off at the screen edge / too much empty space → clamp + fill with mock-ups.
- Unclear, hard-to-hear VO segments must be cut or re-done.
- Hook must be specific and make sense (do not invent things like "uji simultan di SmartPLS" as if it exists); language simple and easy to follow; explain terms (e.g. "simultan" is general Indonesian/KBBI, not only statistics); stop saying "sidang" in every script.
- YouTube VO sounded robotic → paragraph synthesis + reference voice; subtitles untidy → phrase cues; brand on YouTube = NotYourLecture; acronyms must not be spelled letter by letter.
- Title and thumbnail in the same language; add "Sub Indo" when VO is English and title is Indonesian.

## Kenapa format ini bekerja
Talking head + visual mockup cepat, hook spesifik di 2 dtk pertama, satu takeaway jelas, CTA komen-kata-kunci. User suka talking head dan maskot yang bergerak; ubah hook dan ide, bukan formatnya.

## Known small issues
- TikTok/IG handle on the end card = @researchq.id for both (confirm if it changes).
- "a" is occasionally read as "ay" by the English voice; check after synthesis.
- ZipVoice may drop first words if prompt text ≠ prompt audio.
- GitHub model downloads can 504: retry.

## Disk / render hygiene
Frames are huge: delete finished frame folders by absolute path; check `df -h` before starting; run 4 render workers in the background and poll file count (never `pgrep -f`).

## QA sebelum mengirim ke user (WAJIB, ditambahkan setelah video "Sejarah SEM")
Feedback user: animasi kurang terasa bercerita / sejarah, suara AI kurang cocok, SFX "ngawur". Penyebab: hanya frame diam dan transkrip yang diperiksa. Mulai sekarang:
1. **Sampel dulu, render penuh belakangan.** Kirim sampel suara 20-30 dtk, satu adegan beranimasi 5-10 dtk, dan cuplikan SFX. Render penuh hanya setelah user setuju.
2. **Cek gerak, bukan hanya frame diam.** Susun frame berurutan (mis. 1 frame/detik) dan tandai adegan yang statis > ~3 dtk atau gerak kamera yang tidak punya tujuan cerita.
3. **Audio: ukur apa yang bisa diukur** (loudness SFX vs VO, apakah SFX menimpa kata, spektrum/clipping). Nada dan emosi suara TIDAK bisa dinilai oleh Claude: tulis "audio belum didengar" dan jangan mengklaim sudah beres.
4. **SFX harus cocok dengan genre.** Cerita/sejarah: ambience halus, kertas, tinta, lonceng, tick jam. Hindari "pop UI", "ding", dan whoosh otomatis dari kecepatan kamera. Jadwalkan SFX secara manual per adegan dan dengarkan alasannya (apa yang dibunyikan), jangan dari daftar event otomatis.
5. **Suara AI untuk storytelling** harus dites dulu: pace lebih lambat, jeda dramatis, intonasi naratif. Jika tidak cocok, tawarkan alternatif (rekam sendiri / voice lain) sebelum membuat animasi.
6. **Rancang animasi sesuai genre.** Storytelling sejarah = satu adegan per momen (tokoh/objek/tempat/dokumen, perubahan era, transisi waktu), bukan slide kartu. Jelaskan konsep visual dan minta persetujuan storyboard sebelum membangun.
7. **Laporan jujur** saat mengirim: apa yang sudah diperiksa, apa yang belum (audio, gerak), dan risiko yang tersisa.

## Bahasa Indonesia untuk naskah dan subtitle (feedback user)
Jangan menerjemahkan dari Inggris. Tulis langsung dalam Indonesia lisan yang natural dan santai (gaya ngobrol), kalimat pendek, satu ide per kalimat, hindari kata akademis yang berbelit dan pola "X membawa Y ke Z". Bacakan dalam hati: kalau terdengar seperti buku teks, tulis ulang. Berikan teks ke user untuk dibaca dulu sebelum dipasang di video.

## Koreksi user (Parametrik vs Nonparametrik v4)
- **Subtitle TANPA kotak/pill.** Teks polos dengan outline tipis (text-shadow 8 arah): teks navy + outline putih di latar terang; teks putih + outline navy di latar gelap/oranye. Kata kunci oranye/kuning.
- **Elemen harus lurus/sejajar.** Ikon berpasangan (Save/Follow) sama tinggi, label satu baseline, komposisi di tengah; jangan pakai `zoom` CSS yang menggeser posisi; jangan ada rotasi pada subtitle.
- **Aksen pojok harus relevan dengan topik.** Bentuk "burst" mirip logo Claude ditolak untuk konten statistik. Konten statistik = simbol Σ (sigma); topik lain pilih simbol yang sesuai (mis. kurva, panah jalur untuk SEM).
- **Artikel jangan cuma judul kecil.** Animasikan "buka artikel" (sampul berputar terbuka), lalu kamera cepat (±0.45 dtk, motion blur) zoom ke paragraf/tabel yang dikutip, highlight sinkron dengan VO. Halaman PDF 220 dpi, kamera keyframe [t, x, y, skala] (template DEFAULT_explainer_v4: `RCAM`).
- **SFX dilarang: bunyi seperti "tombol salah"/buzzer.** Sampel `s09 flut` di sfxref = dengung 80 Hz → JANGAN dipakai. Hindari juga noise dengan tremolo cepat. Cek spektrum: tidak boleh ada nada rendah berkelanjutan (<300 Hz) di track SFX selain hit/boom singkat.

## Koreksi user (video "Instan dan Cepat", cinematic storytelling)
- **JANGAN pakai "suara kaget"**: boom, sub-hit, impact, braam, spark/flash hit, riser dramatis. User sudah berkali-kali menolak. Aksen cukup dengan swoosh lembut, pop/klik UI, tick, typing, chime lembut. Cek spektrum: track SFX tidak boleh punya jendela yang didominasi frekuensi < 250 Hz.
- **Foto/B-roll secukupnya: maksimal ±8 foto untuk video ±75 dtk.** Sisanya harus **komponen animasi** (motion graphics): progress bar, mockup HP, grid/ikon beranimasi, kartu UI, chat AI, jaringan node, flowchart, meter, grafik garis, timeline. Foto dipakai untuk momen emosional/suasana (hook, nostalgia, refleksi), bukan untuk setiap kalimat.

## Koreksi user (Instan dan Cepat, versi gaya InsiderForce)
- **DILARANG PERMANEN: suara "soft"**, yaitu desis/noise band-pass (±700–1800 Hz) yang membengkak pelan ±0,7 dtk dan dipakai sebagai transisi. User: "jangan pernah pakai sound itu lagi". Hindari juga whoosh dari noise sintetis. Transisi cukup tanpa suara, atau sampel swoosh s13 yang pelan.
- **Bagian YouTube** → tampilkan video asli channel NotYourLecture (thumbnail + judul dari screenshot channel yang dikirim user), bukan kartu tutorial generik.
- **Bagian AI** → tampilkan deretan logo AI (Claude, ChatGPT, Gemini, Perplexity, Copilot). Sumber: glyph resmi **Simple Icons** (CC0) di cdn.jsdelivr.net/npm/simple-icons@13.21.0/icons/<nama>.svg, diwarnai warna merek. Jangan menggambar logo sendiri. Bila user mengirim file logo resmi, pakai file itu.
- **Bagian TikTok** → feed "Untuk Anda" penuh konten yang bergulir (grid tile berwarna + label kategori), bukan layar kosong.
- **Bagian live** → UI live streaming lengkap: host, badge LIVE, jumlah penonton naik, hati beterbangan, chat bergulir berisi pertanyaan riset (validitas, sampel, PLS-SEM vs CB-SEM, jurnal Q1, Bab 4), pertanyaan disematkan, kolom "Tulis pertanyaan…", label "ilustrasi".
- **Cerita pribadi** (mis. "waktu kuliah dulu…") → beri backsound sinematik bergaya storyteller. Skrip `tools/music.py` di repo output/instan_dan_cepat/source membuatnya lewat sintesis: piano arpeggio, string pad hangat, cello, reverb, progresi Am–F–C–G, 72 bpm. Volume ±17 LU di bawah VO, fade in/out, hanya di segmen cerita. Di luar segmen cerita tetap tanpa musik.

## Koreksi user: tolak konsep "kartu kecil" (Instan dan Cepat)
- **Maskot tidak boleh di dalam kotak/kartu.** Maskot berdiri bebas: tengah-bawah (hook, penekanan, penutup) atau kanan-bawah.
- **Jangan gambar/foto dalam kotak kecil.** Foto hanya full-screen sebagai latar. Visual lain harus BESAR.
- **Full animasi non-stop:** tidak ada momen statis. Kamera selalu bergerak (push, drift, rotasi), punch-in di kata kunci, elemen latar bergerak (sinar, titik, garis, blob, grain).
- **Latar harus berganti tiap adegan**, berbeda warna dan tekstur (gradasi, halftone, kertas bergaris, grid, titik, speed-line, foto sepia, split diagonal).
- **Maksimalkan ruang:** isi layar dari atas sampai ±1450 px. Tipografi raksasa, UI full-screen, grid besar.
- **Transisi bervariasi** (whip, zoom-through, swing, flip 3D, circle reveal, rewind, slide), jangan cut polos terus.
- Template yang disukai untuk ini: repo output/instan_dan_cepat/source/template_full.html (engine adegan + transisi + kamera + maskot bebas).
