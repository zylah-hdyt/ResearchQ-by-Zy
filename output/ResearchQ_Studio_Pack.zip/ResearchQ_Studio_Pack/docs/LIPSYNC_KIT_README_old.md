# ResearchQ Lip-Sync Kit (maskot talking head)

Lip-sync TANPA perlu gambar versi mulut tertutup. Tekniknya: "potong mulut lalu animasikan".

## Isi folder
- `poses/b_<pose>.png` = gambar pose dengan latar transparan dan MULUT SUDAH DIHAPUS (wajah polos, ditambal warna kulit).
- `poses/mo_<pose>.png` = potongan mulut (sprite) dari pose tersebut.
- `poses/mouth.json` = posisi mulut per pose (piksel, di gambar aslinya):
  - x, y, w, h : kotak sprite mulut di gambar pose
  - top        : jarak bibir atas dari tepi atas sprite (titik engsel buka-tutup)
  - s          : skala tampil yang disarankan supaya ukuran wajah semua pose sama
  - W, H       : ukuran gambar pose (hanya untuk pose baru n_*)
- 9 pose:
  - m_open, m_thumb, m_think, m_point, m_warn (pose lama, ada meja)
  - n_present, n_idea, n_shrug, n_wink (pose baru, setengah badan)

## Cara kerja lip-sync
1. Tampilkan `b_<pose>.png` (wajah tanpa mulut).
2. Tempel `mo_<pose>.png` tepat di (x, y) dengan ukuran (w, h), dikali skala s.
3. Setiap frame video, ubah TINGGI sprite mulut (scaleY) sesuai volume suara VO pada detik itu:
   - scaleY = minimum + (1 - minimum) * buka
   - minimum ≈ 0.13 untuk pose senyum (mulut jadi garis tipis = terlihat tertutup),
     0.3 untuk m_think, 0.22 untuk m_warn
   - transform-origin di bibir atas (top + 18% tinggi mulut), supaya rahang yang "turun"
   - opsional: scaleX sedikit melebar untuk bunyi i/e/s
4. Nilai "buka" (0..1) per frame dihitung dari audio VO oleh `scripts/lipdata.py`:
   - RMS band suara 200–3500 Hz per frame (60 fps), dalam dB
   - dinormalisasi terhadap level bicara, plus modulasi suku kata (dibanding rata-rata 250 ms)
   - attack cepat, release ±70 ms
   - output: `lip.json` = {"o": [buka per frame], "w": [lebar per frame]}

## Pemakaian script
- `python lipdata.py <folder>` → membaca `<folder>/work/vo_final.wav`, menulis `<folder>/lip/lip.json`
- `mascot.js` → contoh kode browser (HTML/JS) yang memasang pose dan menggerakkan mulut per frame
  (butuh variabel MAS, MO, MI, LIP, dan PT = daftar [detik, nama_pose]).
- `prep.py` / `prep2.py` → cara membuat aset ini dari gambar pose BARU
  (deteksi mulut lewat warna lidah, potong sprite, tambal wajah).
  Hanya perlu dipakai kalau ada pose baru.

## Kalau tidak bisa menjalankan kode
Untuk editor video biasa (CapCut dan sejenisnya):
- Taruh `b_<pose>.png` sebagai layer dasar.
- Taruh `mo_<pose>.png` di atasnya pada posisi mouth.json.
- Animasikan skala tinggi mulut naik turun mengikuti suara (keyframe).
