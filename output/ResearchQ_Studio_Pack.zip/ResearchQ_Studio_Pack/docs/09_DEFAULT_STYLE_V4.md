# 09 · GAYA DEFAULT (v4): "Parametrik vs Nonparametrik"

**Ini gaya yang dipilih user sebagai standar untuk semua video vertikal baru** (TikTok/IG/Shorts, VO rekaman user, 30–90 dtk), apa pun topiknya: SPSS, SmartPLS, Claude, metodologi penelitian.
Referensi (hanya 2 video, sengaja tanpa referensi lama): `reference/videos_480p/1_DEFAULT_v4_Parametrik_vs_Nonparametrik.mp4` (gaya utama) dan `2_MODUL_SPSS_Doctor_Claude_UI.mp4` (modul UI Claude + presenter bergerak). Template: `code/templates/DEFAULT_explainer_v4/`.
Kalau ada konflik dengan dokumen lama (02, template lama), **dokumen ini menang**.

## 1. Komposisi
| porsi waktu | isi |
|---|---|
| ±60% | motion graphic & visualisasi TANPA maskot: kartu, grafik, diagram cabang, kutipan artikel, mockup software |
| ±25% | talking head (maskot besar, lip-sync) HANYA di: hook/opening, 1 penekanan konsep penting, CTA |
| ±15% | maskot kecil "stiker" (skala 0.6, pojok bawah, 1.5–4 dtk) saat reaksi/alternatif/penawaran + aksen branding Σ |

Maskot: 9 pose di `assets/mascot/` (JANGAN mengubah/menggambar ulang). Saat tampil, maskot selalu bergerak (napas, ganti pose sesuai kalimat, masuk/keluar dengan geser); tidak diam di pojok.

## 2. Latar berganti per adegan
Tiap adegan punya tema sendiri, berganti dengan **circle-wipe** dari titik berbeda + dot grid yang bergerak pelan:
`light #F6F7FB` · `cream #F2EFE6` · `dark navy (radial #163065→#060D1E)` · `blue (gradien #2F6FD6→#163A8A)` · `orange (gradien #FF9F43→#F2672E)`.
Urutan contoh: hook light → save/follow orange → artikel cream → bagian 01 dark → bagian 02 light → ringkasan/software dark → penawaran blue → bonus cream → CTA orange. Jangan dua adegan berturut-turut bertema sama; jangan monoton biru.
Kartu gelap (#0F1C3A) di atas latar terang (kontras seperti screenshot gelap).

## 3. Elemen khas
- **Angka bagian besar bergradasi** ("01 Korelasi", "02 2 Kelompok Independen"), 420 px, muncul 1.2 dtk sebelum isi bagian.
- **Aksen pojok = simbol relevan topik.** Statistik: **Σ** oranye dari 2 sudut di setiap ganti adegan (di tema oranye jadi putih transparan). Jangan pakai bentuk burst yang mirip logo Claude. Topik lain: pilih simbol yang cocok (mis. panah jalur untuk SEM).
- **Artikel/jurnal = "buka artikel" + kamera cepat.** Sampul jurnal (judul, penulis, tahun) berputar terbuka (rotateY 0→-100°, 0.6 dtk) → halaman asli tampil penuh → saat VO masuk ke isi, kamera zoom cepat (0.45 dtk, motion blur) ke paragraf/tabel yang dikutip → highlight kuning/biru menyapu sinkron dengan kata VO → geser kamera untuk kalimat kedua. Chip ringkasan bahasa Indonesia ditempel di bawah frame. Sumber kecil: "Penulis (tahun) · Jurnal vol(no)". Halaman dari `pdf_pages.py` (220 dpi).
- **Save & Follow:** ikon sama tinggi, label satu garis, rata tengah. Save muncul sendiri di tengah, lalu bergeser kiri saat "follow" disebut. Tidak boleh miring.
- **Diagram cabang** (Data normal? → ✓ parametrik / ✗ nonparametrik) dengan garis yang digambar (strokeDashoffset) dan kartu pop.
- **Kartu ringkasan** ("Metode yang tepat ✓") sebelum masuk ke bagian produk/CTA.
- Watermark "ResearchQ●" kiri bawah (warna menyesuaikan tema).

## 4. Subtitle kinetic Indonesia
- **TANPA kotak/pill.** Teks PJS 800, 52 px (kata kunci 58 px), outline 8 arah lewat text-shadow: tema terang → teks navy + outline putih, kata kunci oranye #E8711A; tema gelap/oranye/biru → teks putih + outline navy, kata kunci kuning #FFD166.
- Kata muncul satu per satu tepat saat diucapkan (4 gerak bergantian: up / pop / slide / drop, tanpa rotasi); kata yang belum diucapkan **tidak memakan tempat** sehingga baris selalu rata tengah.
- Posisi: maskot besar → y 1050; maskot samping → y 1130; tanpa maskot → y 1250. Jangan menabrak kartu/frame artikel (cek!).

## 5. Audio
- VO user dibersihkan (`code/engine/vo_proc.py` + EQ/de-ess/compress → -16 LUFS). Tidak ada musik (user tambah di TikTok).
- SFX dari `assets/sfx` (+ sintesis ringan), ±9 LU di bawah VO: swoosh tiap ganti adegan, pop/klik untuk kartu, "open" (swoosh pelan + pop rendah) saat artikel dibuka, "zoom" (swoosh cepat) saat kamera masuk, marker (desis lembut tanpa tremolo) untuk highlight, ding untuk produk, riser + hit + confirm di CTA.
- **DILARANG:** bunyi yang terdengar seperti "tombol salah"/buzzer kuis (sampel lama s09 sudah dihapus dari pack), noise bertremolo, nada rendah panjang. Cek spektrum track SFX sebelum mix.
- Master: `loudnorm=I=-14.5:TP=-2:LRA=11` → hasil ±-14.8 LUFS, peak ±-1.8 dBFS.

## 6. Modul tambahan: UI Claude (dari video SPSS Doctor)
Dipakai bila topiknya Claude/skill: jendela chat "Claude" (teks, tanpa logo kecuali dari user) dengan lampiran file, balasan mengetik, kartu `SKILL.md` yang "terbang" masuk ke chat, kartu hasil. CSS `.cw/.hd/.ub/.att/.rp/.in/.sk` + fungsi `typeTo()` ada di `code/templates/spss_doctor_presenter/template.html`; salin ke template default. Subtitle berkotak dan latar biru-saja di video itu SUDAH USANG: ikuti bagian 2 dan 4 dokumen ini.

## 7. Pipeline (perintah)
Lihat `code/templates/DEFAULT_explainer_v4/README.md` (langkah 0–10, bisa langsung dijalankan).

## 8. QA wajib sebelum kirim (docs/06)
1. Kirim sampel dulu bila gaya/topik baru (1 adegan + SFX) dan minta persetujuan.
2. Contact sheet 2 fps dari video FINAL (bukan hanya frame kunci): cek tumpang-tindih subtitle vs kartu/artikel/maskot, teks terpotong, elemen miring, latar berganti, Σ tampil.
3. Cek loudness (ebur128) dan spektrum SFX. Katakan jujur bila audio belum didengar.
4. Bahasa Indonesia natural (bukan terjemahan); fakta yang dikutip harus benar-benar ada di artikel (jangan atribusikan Pearson/Spearman ke artikel yang tidak membahasnya).

## 9. Gaya "cinematic storytelling" (video Instan dan Cepat)
Bila user minta gaya sinematik/dokumenter: tetap presenter (maskot) sebagai fokus, foto realistis maksimal ±8 (Unsplash/Pexels resmi, catat URL + lisensi), dibuat bergerak dengan depth parallax 2.5D (Depth-Anything ONNX + shader WebGL), dan SEBAGIAN BESAR adegan berupa komponen animasi di latar grafis sinematik (night navy / kertas hangat untuk masa lalu / modern electric-blue) dengan grain film. Kode: repo `output/instan_dan_cepat/source/`. Tanpa suara kaget.

## 10. Gaya "InsiderForce" (kartu melayang di latar abu-terang)
Disukai user (video Instan dan Cepat, versi REFSTYLE). Ciri:
- latar abu-terang polos;
- satu kartu visual melayang (bayangan besar, miring 3D) di y ±300–1000;
- caption hitam di bawahnya (kata abu→hitam, kata kunci tebal & besar);
- daftar ✦ dan langkah bernomor dalam lingkaran biru;
- angka besar menumpuk di bawah kartu;
- label pill monospace /perintah;
- watermark domain abu pucat;
- maskot hanya di dalam kartu presenter, maksimal ±5 kali.
Template: repo output/instan_dan_cepat/source/template_ref.html.
