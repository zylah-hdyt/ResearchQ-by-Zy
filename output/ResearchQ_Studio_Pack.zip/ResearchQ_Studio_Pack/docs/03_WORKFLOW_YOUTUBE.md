# Workflow: YouTube long-form (1920x1080 @30 fps, ~5 min), English VO + EN/ID subtitles

Reference implementation: `code/templates/landscape_youtube/` (template.html, script.py = the 7-mistakes script, subs.py/subs.json = bilingual cues) and `code/voice_tts/`.

1. **Script** in `script.py`: list of lines `(section, english_text_for_screen, text_for_tts, indonesian_text)`. Each line is a short sentence. TTS text may differ from screen text (e.g. `H.T.M.T.` → "H T M T", `PLS-SEM` → `PLS SEM` WITHOUT dots/hyphen or the voice spells letters).
2. **Subtitles** `subs.py`: every line is cut into phrase cues as (EN, ID) pairs; `' '.join(EN parts) == line text` is asserted. Run it to create `subs.json`.
3. **Voice-over (English).** ZipVoice full model cloned from `assets/voice/prompt_pad.wav` (text in `assets/voice/prompt_text.txt`). `code/voice_tts/zv_build.py <workspace>` synthesizes 2-3 lines at a time (≤ 300 chars) for natural flow, 32 steps; retries with other steps/speed when the Whisper check covers < 97% of the words. Then `realign.py` times every word (anchors at pauses). `fix_acr.py` / `fix_chunk.py` re-synthesize one line without redoing everything. `run_all.sh` = whole chain from alignment to final mp4 (edit its paths).
4. **Mix**: VO EQ + deesser + compressor → -16 LUFS; SFX 11 LU below; final ≈ -14 LUFS.
5. **Template** (`template.html`): sections intro / m1..m7 / outro, circle-wipe backgrounds, title cards, myth card, source card, excerpt cards (pdfplumber word boxes → highlight boxes: `excerpt.py`), recap grid, end card. Build with `code/engine/build_html_landscape.py` (adapt paths).
6. **Render** with `recp_landscape_30fps.js` (4 workers), encode: `ffmpeg -framerate 30 -i sub/f%05d_0.jpg -i mix.wav -c:v libx264 -crf 20 -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart`.
7. **SRT files** `srt2.py` → `subtitle_en.srt`, `subtitle_id.srt` from the same cues.
8. **YouTube package**: title (English title + Indonesian translation), description with CHAPTERS (first at 0:00, ≥3, each ≥10 s), references, hashtags (≤ 15, first 3 show above the title), tags, thumbnails (`thumbnails/`), tick "altered or synthetic content" (AI voice).
9. Title/thumbnail language must match: thumbnail Indonesian → title Indonesian + "Sub Indo" because the VO is English.

Known quirks: the article "a" is sometimes pronounced "ay"; check the audio around numbers (0.90, 155, 5%).
