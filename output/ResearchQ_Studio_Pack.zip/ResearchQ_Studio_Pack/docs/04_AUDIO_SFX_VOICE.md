# Audio, SFX and voice

## Loudness (gaya default v4)
- VO: highpass 70 Hz, +1 dB @180 Hz, +1 dB @3.5 kHz, de-esser, compressor (threshold -22 dB, ratio 2) → -15.5/-16 LUFS (`code/engine/vo_proc.py` + rantai ffmpeg di `code/voice_tts/run_all.sh` baris 3).
- SFX di-mix **±9 LU di bawah VO** (hitung gain: `GS = (LUFS_VO - 9) - LUFS_SFX`), lalu master `loudnorm=I=-14.5:TP=-2:LRA=11` → ±-14.8 LUFS, peak ±-1.8 dBFS (AAC tidak boleh >0 dBFS).
- Tanpa musik latar (user menambahkan musik di TikTok/IG).

## SFX
- Sumber: `assets/sfx/` (14 sampel, lihat `SFX_CATALOG.md`) + sintesis ringan. Mixer siap pakai: `code/templates/DEFAULT_explainer_v4/audio.py`. Daftar event dibuat otomatis dari `window.SFXLIST()` di template (`dumpev.js` → `work/events.json`), dijadwalkan dari waktu kata (`FW(kalimat,'kata')`).
- Kosakata: swoosh tiap ganti adegan · pop/klik untuk kartu (pitch berbeda per kartu) · `open` (swoosh pelan + pop rendah) saat artikel dibuka · `zoom` (swoosh cepat) saat kamera masuk · `marker` (desis lembut tanpa tremolo) untuk highlight · ding untuk produk · riser + hit + confirm di CTA.
- **Dilarang:** bunyi seperti "tombol salah"/buzzer, **"suara kaget" (boom, sub-hit, impact, riser dramatis)**, **desis "soft" (noise band-pass yang membengkak sebagai transisi)**, noise bertremolo, nada rendah panjang (<300 Hz). Sampel `s09` sudah dihapus. Variasikan sampel agar tidak monoton; jangan ramai.

## English AI voice (YouTube)
- Engine: **ZipVoice** (sherpa-onnx) with voice cloning from `assets/voice/prompt_pad.wav` + `prompt_text.txt`. Kokoro (am_michael) was tried and rejected as "jelek / robot".
- Use the FULL model (`text_encoder.onnx`, `fm_decoder.onnx`) with the lexicon of the distilled model, vocoder `vocos_24khz.onnx`, 32 steps, speed 1.0 (fallback .98 / .96).
- Generate paragraphs (2-3 lines, ≤ 300 chars) not single lines: intonation flows. Gap between chunks: 0.42-0.54 s inside a section, 1.3-1.45 s between sections.
- Acronyms: write `PLS SEM`, `SEM PLS`, `H T M T`, `G O F` in the TTS text (no dots, no hyphen) or the voice spells letters. Numbers: spell out in TTS text ("zero point nine").
- The reference prompt text must match the prompt audio exactly.
- Quality check every chunk with Whisper: word coverage ≥ 97% else regenerate (`zv_build.py` does this).
- Ethics: only clone your own voice or one with permission; tell YouTube it is synthetic.

## Indonesian human VO (TikTok)
User records on a phone (.m4a). Clean it, do not replace it. Trim breaths/long pauses (< 180 ms kept), keep natural rhythm.
