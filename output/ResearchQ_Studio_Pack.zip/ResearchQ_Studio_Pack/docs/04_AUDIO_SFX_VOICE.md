# Audio, SFX and voice

## Loudness targets
- VO chain: highpass 70 Hz, +1 dB @180 Hz, +1 dB @3.5 kHz, de-esser (i=0.3), compressor (threshold -22 dB, ratio 2, attack 8, release 120, makeup 1.5) → normalize to **-16 LUFS**, limiter 0.84.
- SFX mixed so that their loudness is **11 LU below** the VO, then final gain +2.2 dB and limiter 0.87. Final file ≈ **-14 LUFS**, true peak below -1 dBFS. (The exact ffmpeg lines are in `code/voice_tts/run_all.sh`.)
- No music bed. SFX are calm and sparse; vary sounds (see `assets/sfx/SFX_CATALOG.md`).

## SFX scheduling
Time every SFX from the word onsets (`words.json`) so it lands on the word, e.g. pop when a card enters, one "ding" per checklist item with rising pitch, a low "boom" (trimmed) on stamps, typing sound for search-bar scenes, swoosh for slides. See `code/engine/audio_sfx_timeline_example.py` (it execs the synth part of `sfx_synth.py` and then places sample-based SFX with `putS`).

## English AI voice (YouTube)
- Engine: **ZipVoice** (sherpa-onnx) with voice cloning from `assets/voice/prompt_pad.wav` + `prompt_text.txt`. Kokoro (am_michael) was tried and rejected as "jelek / robot".
- Use the FULL model (`text_encoder.onnx`, `fm_decoder.onnx`) with the lexicon of the distilled model, vocoder `vocos_24khz.onnx`, 32 steps, speed 1.0 (fallback .98 / .96).
- Generate paragraphs (2-3 lines, ≤ 300 chars) not single lines: intonation flows. Gap between chunks: 0.42-0.54 s inside a section, 1.3-1.45 s between sections.
- Acronyms: write `PLS SEM`, `SEM PLS`, `H T M T`, `G O F` in the TTS text (no dots, no hyphen) or the voice spells letters. Numbers: spell out in TTS text ("zero point nine").
- The reference prompt text must match the prompt audio exactly.
- Quality check every chunk with Whisper: word coverage ≥ 97% else regenerate (`zv_build.py` does this).
- Ethics: only clone your own voice or one with permission; tell YouTube it is synthetic.

## Indonesian human VO (TikTok)
User records on a phone (.m4a). Clean it, do not replace it. Trim breaths/long pauses (< 180 ms kept), keep natural rhythm.
