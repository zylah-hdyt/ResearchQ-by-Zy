# Workflow: vertical video (TikTok / Reels, 1080x1920 @60 fps, ~30-60 s) with lip-sync mascot

Workspace convention used by the old scripts: a folder `$S` that contains the pack assets, e.g. `$S/<project>/`. The scripts in `code/engine/` take paths as arguments. Easiest: unzip the pack to `$S/pack`, create `$S/<project>/{work,lip,sub}`, copy `code/templates/template.html` into `<project>/`.

1. **Script** (user records VO as .m4a). Follow `docs/06_RULES_AND_LESSONS.md` for hook/language.
2. **Clean the VO + word timings** (Indonesian VO recorded on a phone). `python3 code/engine/vo_proc.py in.m4a work/vo_clean.wav work/map.json` = denoise from the room tone, trim long pauses; then ffmpeg EQ / de-ess / compress / normalize to -16 LUFS 48 kHz → `work/vo_final.wav` (exact ffmpeg chain: `code/voice_tts/run_all.sh`, 3rd line). Split into sentences (`sentences.json` = `[[start, end, "text"], ...]`, 16 kHz copy `vf16.wav`) and run `code/engine/align_words.py <S> <project>`: Whisper turbo (sherpa-onnx, language `id`) has no native timestamps, so words are timed by prefix-probing each phrase → `work/words.json`: per line `{s, e, sec, id, words:[[word, onset_seconds], ...]}`. Full worked chain with its inputs: `code/examples/source_pedoman/` (vo_proc → align → audio → build) and `code/templates/` (newest).
3. **Lip data.** `python3 code/engine/lipdata.py <project>` → `lip/lip.json` (60 fps arrays `o` = openness, `w` = width). Needs `work/vo_final.wav`.
4. **Storyboard** each sentence: background, scene, mock-ups, pose. Ask the user to approve before a long render.
5. **Build the HTML.** Edit `template.html` (scenes are in `body.js` → inserted by `mk_template.py`). Then `python3 code/engine/build_vertical_portable.py <pack_root> <project> words.json` → `<project>/video.html` (everything embedded). Placeholders in the template: `{{INTER500}} {{PJS800}} {{JBM500}} {{IS400I}} {{ANTON}} {{PAPER}} {{GRAIN}} {{MOUTHS}} {{MOUTHINFO}} {{LIP}} {{MASCOT}} {{LOGOS}} {{WORDS}}` (+ `{{HAIR}}` only in the SEM-PLS video: remove if unused). The page exposes `render(t, frameIndex, t)`; everything is a pure function of time.
6. **Check before the full render.** `node code/engine/shot_check.js 1.5,4,9,15 shots` (copy next to `video.html`): writes JPGs and reports elements outside the safe zone and JS errors. Build a contact sheet and LOOK at it (overlaps, cut-off text, mascot clipped, empty space).
7. **Render.** Copy `recp_vertical_60fps.js` to `recp.js` next to `video.html` (it loads `__dirname/video.html`). `node recp.js <startFrame> <endFrame>`: 60 fps, 3 sub-frames per frame (180° shutter motion blur). Run 4 workers in parallel in the background with `nohup`, e.g. `SUB=sub node recp.js 0 1100 &`. Frames = duration x 60 x 3 images (`f00000_0.jpg`). Poll the count with `ls sub | wc -l`. Check for truncated jpgs afterwards (`find sub -size -20k`) and re-run missing ones (the worker skips existing files).
8. **Audio.** SFX from `assets/sfx` timed by word onsets (`code/engine/audio_sfx_timeline_example.py`), mix: VO -16 LUFS, SFX ≈ 11 LU below VO, final ≈ -14 LUFS (see docs/04).
9. **Encode.** `python3 code/engine/encode_blend.py <project> <numFrames> out.mp4 mix_final.wav sub` : averages the 3 sub-frames, libx264 crf 16, aac 320k, faststart.
10. **Deliver** the mp4 + a timing table (start second of each sentence) + the list of claims that need fact-checking. Say honestly that the audio was not heard by you.

Disk: 60 fps x 3 jpgs is big (~5-10 GB for 40 s). Delete old frame folders when done.

## Also produced for TikTok
- Caption (short), cover prompt for ChatGPT (ratio 3:4 requested before), hashtags.
- Cover images: `output/Cover_*.png` in the repo are examples.

## Verified in this pack
The pack was smoke-tested: `build_vertical_portable.py` + `shot_check.js` on `code/templates/template.html` render correctly (mascot poses, fonts, backgrounds, cards). Only the Hair book cover/excerpt scenes are blank, because the book images are not in the pack. The template is the SEM-PLS "uji simultan" video: for a new topic rewrite the scenes (`body.js` → `mk_template.py` → `template.html`) and keep the engine parts (`MASCOT`, `MOUTH`, kinetic captions `CAP`, `CTA`, backgrounds `BGF`).
