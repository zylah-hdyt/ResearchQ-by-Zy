# ResearchQ / NotYourLecture – Studio Pack

Everything needed to make new motion-graphic videos in the SAME style as the existing ones (TikTok/IG vertical + YouTube landscape), for any topic: **Claude AI, SPSS, SmartPLS, penelitian umum**.

## How to use it in a NEW chat
1. Start a new Claude chat (Claude Code / cloud session with a code sandbox, so it can run Python, Node, ffmpeg).
2. Upload `ResearchQ_Studio_Pack.zip` (or unzip it into the working folder).
3. Paste this first message (edit the topic):

> Baca `START_HERE.md` dan semua file di `docs/` dari pack yang saya upload. Pakai pack itu sebagai style, maskot, SFX, voice, dan engine render. Buat video **[TikTok vertikal 40 dtk / YouTube 5 menit]** tentang **[topik]**. Script/VO: **[saya rekam sendiri → saya kirim .m4a] / [buatkan script dulu]**. Jangan mengubah maskot, ikuti aturan di `docs/01_STYLE_GUIDE.md`.

4. For a voice-over you record yourself: send the .m4a in that chat. For an English AI voice (YouTube): the pack has your voice reference (`assets/voice/prompt_pad.wav`).

## What is inside
| folder | contents |
|---|---|
| `docs/` | 01 style guide · 02 vertical workflow · 03 YouTube workflow · 04 audio, SFX, voice · 05 topic playbooks (Claude, SPSS, SmartPLS, penelitian) · 06 rules and lessons · old script PDFs |
| `assets/mascot/` | 9 mascot poses (`poses/`), 9 separate mouth sprites (`mouths/`), `mouth.json` (mouth position/scale per pose), `MASCOT_SHEET_9_poses.png` (what each pose is for) |
| `assets/logos/` | TikTok, Instagram, YouTube logos (the ones you supplied; never redraw) |
| `assets/fonts/` | Plus Jakarta Sans 800, Instrument Serif italic, JetBrains Mono, Inter, Anton (woff2, embedded into the HTML) |
| `assets/textures/` | paper + 8 grain textures |
| `assets/sfx/` | 15 SFX + `SFX_CATALOG.md` |
| `assets/voice/` | `prompt_pad.wav` + text: reference for ZipVoice voice cloning |
| `reference/` | 7 final videos in low resolution (style references), your viral reference video, contact sheets |
| `code/engine/` | render + lip-sync + audio + subtitle scripts |
| `code/templates/` | newest vertical template (+ `landscape_youtube/` for 16:9) |
| `code/voice_tts/` | English voice-over pipeline (ZipVoice + Whisper alignment) |
| `code/examples/` | source of the older videos (Pedoman, Piramida, ATM, Why Claude, Ekosistem, Fenomena) |
| `thumbnails/` | YouTube thumbnail template + 4 finished examples |
| `setup/` | `install.sh`, `download_models.sh` |

## NOT in the zip (on purpose)
- **Speech models** (~3 GB): `setup/download_models.sh` downloads them.
- **Claude logo**: you never sent one. Upload it in the new chat when a video needs it (docs/06).
- **Hair et al. book PDF** (copyright, 12 MB): upload it again if a new video quotes it.
- Final full-resolution videos: they stay in the GitHub repo `output/` folder.

## Fixed facts
- Brands: TikTok/IG **@researchq.id**; YouTube **NotYourLecture** (the YouTube video's on-screen brand is "NotYourLecture", not "ResearchQ").
- Vertical 1080x1920 @60 fps (3-sub-frame motion blur) · YouTube 1920x1080 @30 fps.
- Palette `#F2EFE9` cream · `#141311` ink/dark · `#EE6A1F` orange. (Piramida used navy / white / light blue – topic-specific.)
