# ResearchQ / NotYourLecture – Studio Pack

Everything needed to make new motion-graphic videos in the SAME style as the existing ones (TikTok/IG vertical + YouTube landscape), for any topic: **Claude AI, SPSS, SmartPLS, penelitian umum**.

## ⭐ GAYA DEFAULT = v4 (dipilih user)
Semua video vertikal baru memakai gaya **"Parametrik vs Nonparametrik v4"**: latar berganti tiap adegan, maskot hanya di opening/penekanan/CTA (komposisi 60/25/15), subtitle kinetic TANPA kotak, aksen Σ, "buka artikel + kamera zoom" untuk sumber jurnal.
- Spesifikasi: `docs/09_DEFAULT_STYLE_V4.md` (dokumen ini menang bila bertentangan dengan dokumen lama)
- Template + pipeline siap pakai: `code/templates/DEFAULT_explainer_v4/` (README berisi semua perintah)
- Contoh jadi: `reference/videos_480p/DEFAULT_v4_Parametrik_vs_Nonparametrik.mp4`

## How to use it in a NEW chat
1. Start a new Claude chat (Claude Code / cloud session with a code sandbox, so it can run Python, Node, ffmpeg).
2. Upload `ResearchQ_Studio_Pack.zip` (or unzip it into the working folder).
3. Paste this first message (edit the topic):

> Baca `START_HERE.md`, `docs/09_DEFAULT_STYLE_V4.md`, lalu semua file lain di `docs/` dari pack yang saya upload. Pakai **gaya default v4** dan template `code/templates/DEFAULT_explainer_v4/` (lihat contoh `reference/videos_480p/DEFAULT_v4_Parametrik_vs_Nonparametrik.mp4`). Buat video **TikTok vertikal [durasi]** tentang **[topik]**. VO: **[saya kirim .m4a] / [buatkan script dulu, saya rekam sendiri]**. [Artikel rujukan: saya lampirkan PDF-nya.] Kirim sampel 1 adegan + SFX dulu sebelum render penuh. Jangan mengubah maskot.

4. For a voice-over you record yourself: send the .m4a in that chat. For an English AI voice (YouTube): the pack has your voice reference (`assets/voice/prompt_pad.wav`).

## What is inside
| folder | contents |
|---|---|
| `docs/` | **09 GAYA DEFAULT v4 (baca dulu)** · 01 style guide · 02 vertical workflow · 03 YouTube workflow · 04 audio, SFX, voice · 05 topic playbooks (Claude, SPSS, SmartPLS, penelitian) · 06 rules and lessons (BACA, termasuk QA sebelum kirim) · 07 video sejarah + penilaian user · 08 analisis gaya Shorts explainer (referensi InsiderForce, versi talking head kita) · old script PDFs |
| `assets/mascot/` | 9 mascot poses (`poses/`), 9 separate mouth sprites (`mouths/`), `mouth.json` (mouth position/scale per pose), `MASCOT_SHEET_9_poses.png` (what each pose is for) |
| `assets/logos/` | TikTok, Instagram, YouTube logos (the ones you supplied; never redraw) |
| `assets/fonts/` | Plus Jakarta Sans 800, Instrument Serif italic, JetBrains Mono, Inter, Anton (woff2, embedded into the HTML) |
| `assets/textures/` | paper + 8 grain textures |
| `assets/sfx/` | 14 SFX + `SFX_CATALOG.md` (s09 buzzer dihapus: jangan dipakai) |
| `assets/voice/` | `prompt_pad.wav` + text: reference for ZipVoice voice cloning |
| `reference/` | 7 final videos in low resolution (style references), your viral reference video, contact sheets |
| `code/engine/` | render + lip-sync + audio + subtitle scripts |
| `code/templates/` | **`DEFAULT_explainer_v4/` (pakai ini)**, older vertical template (+ `landscape_youtube/` for 16:9) |
| `code/voice_tts/` | English voice-over pipeline (ZipVoice + Whisper alignment) |
| `code/examples/` | source of the older videos (Pedoman, Piramida, ATM, Why Claude, Ekosistem, Fenomena) |
| `thumbnails/` | YouTube thumbnail template + 4 finished examples |
| `setup/` | `install.sh`, `download_models.sh` |

## NOT in the zip (on purpose)
- **Speech models** (~3 GB): `setup/download_models.sh` downloads them.
- **Claude logo**: you never sent one. Upload it in the new chat when a video needs it (docs/06).
- **Hair et al. book PDF** (copyright, 12 MB): upload it again if a new video quotes it.
- Final full-resolution videos: they stay in the GitHub repo `output/` folder.

## Fixed facts
- Brands: TikTok/IG **@researchq.id**; YouTube **NotYourLecture** (the YouTube video's on-screen brand is "NotYourLecture", not "ResearchQ").
- Vertical 1080x1920 @60 fps (3-sub-frame motion blur) · YouTube 1920x1080 @30 fps.
- Palette `#F2EFE9` cream · `#141311` ink/dark · `#EE6A1F` orange. (Piramida used navy / white / light blue – topic-specific.)
