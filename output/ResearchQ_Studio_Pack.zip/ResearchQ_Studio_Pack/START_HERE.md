# ResearchQ / NotYourLecture · Studio Pack (gaya default v4)

Paket untuk membuat video motion graphic dengan gaya yang sama untuk semua topik: **Claude AI, SPSS, SmartPLS, penelitian**. Referensi lama sudah dibuang; hanya konsep 2 video terbaru yang dipakai.

## ⭐ Gaya default
Video vertikal (TikTok/IG/Shorts) mengikuti `docs/09_DEFAULT_STYLE_V4.md`: latar berganti per adegan, maskot hanya di opening/penekanan/CTA (komposisi 60/25/15), subtitle kinetic tanpa kotak, aksen Σ, "buka artikel + kamera zoom" untuk sumber jurnal, modul UI Claude bila perlu.
- Template + pipeline siap jalan: `code/templates/DEFAULT_explainer_v4/` (README berisi semua perintah)
- Referensi: `reference/videos_480p/1_DEFAULT_v4_Parametrik_vs_Nonparametrik.mp4`, `2_MODUL_SPSS_Doctor_Claude_UI.mp4`

## Cara pakai di chat baru
1. Gunakan Claude Code / sesi dengan sandbox kode (Python, Node, ffmpeg).
2. Upload `ResearchQ_Studio_Pack.zip` (atau buka sesi di repo yang berisi `CLAUDE.md`).
3. Kirim:

> Baca `START_HERE.md`, `docs/09_DEFAULT_STYLE_V4.md`, lalu semua file lain di `docs/`. Pakai gaya default v4 dan template `code/templates/DEFAULT_explainer_v4/`. Buat video **TikTok vertikal [durasi]** tentang **[topik]**. VO: **[saya kirim .m4a] / [buatkan script dulu, saya rekam sendiri]**. [Artikel rujukan: PDF terlampir.] Kirim sampel 1 adegan + SFX dulu sebelum render penuh. Jangan mengubah maskot.

4. Lampirkan VO (.m4a) dan PDF artikel bila ada.

## Isi
| folder | isi |
|---|---|
| `docs/` | **09 gaya default v4 (baca dulu)** · 01 style guide ringkas · 03 workflow YouTube landscape · 04 audio, SFX, voice · 05 playbook topik · 06 aturan & pelajaran (QA wajib) · 07 video sejarah · 08 analisis referensi explainer |
| `assets/mascot/` | 9 pose, 9 sprite mulut, `mouth.json`, lembar pose |
| `assets/logos/` | TikTok, Instagram, YouTube (dari user; jangan digambar ulang) |
| `assets/fonts/` | Plus Jakarta Sans, Inter, Instrument Serif, JetBrains Mono, Anton |
| `assets/sfx/` | 14 SFX + `SFX_CATALOG.md` (s09 buzzer dihapus) |
| `assets/voice/` | `prompt_pad.wav` + teks: referensi kloning suara ZipVoice (Inggris, YouTube) |
| `assets/textures/` | kertas + grain |
| `code/engine/` | `vo_proc.py` (bersihkan VO), `align_words.py` (timing kata), `lipdata.py` (lip-sync), `shot_check.js`, `sfx_synth.py`, serta skrip landscape (`build_html_landscape.py`, `recp_landscape_30fps.js`, `srt2.py`) |
| `code/templates/` | **`DEFAULT_explainer_v4/`** (utama) · `spss_doctor_presenter/` (modul UI Claude + presenter) · `history_world_map_camera/` (genre sejarah) · `landscape_youtube/` (YouTube 16:9) |
| `code/voice_tts/` | pipeline suara Inggris (ZipVoice + Whisper) |
| `reference/` | 2 video referensi resolusi rendah |
| `thumbnails/` | template thumbnail YouTube |
| `setup/` | `install.sh`, `download_models.sh` |

## Tidak ada di zip (sengaja)
- Model suara (~3 GB): `setup/download_models.sh` mengunduhnya.
- Logo Claude dan ResearchQ: belum pernah diberikan; upload di chat baru bila perlu.
- Buku/PDF berhak cipta: upload ulang bila dikutip.
- Video lama resolusi penuh dan sumbernya: tetap di folder `output/` repo GitHub.

## Fakta tetap
- Vertikal 1080x1920, 30 fps (gaya v4) · YouTube 1920x1080, 30 fps.
- Brand: TikTok/IG @researchq.id · YouTube NotYourLecture.
