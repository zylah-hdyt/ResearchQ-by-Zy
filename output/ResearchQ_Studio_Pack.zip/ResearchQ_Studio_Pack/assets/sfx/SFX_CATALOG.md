# SFX library (48 kHz stereo/mono wav, taken from the reference video's sound palette)
Use via `code/engine/audio_sfx_timeline_example.py` (helpers `putS(t, fit(sound, rate, trim), gain_dB, pan)`).
Names are the variable names used in that script. Typical gains: -17 (important click) ... -30 (quiet tick). Everything is mixed ~11 LU UNDER the voice-over.

| file | name | length | use for |
|---|---|---|---|
| s00 | spark | 1.0 s | magic / reveal sparkle (rare) |
| s01 | boom | 0.62 s | low impact for STAMPS (play trimmed .35 s, rate 1.5, -19 dB) |
| s02 | ding | 0.33 s | checklist tick, success. Step the rate up (1.0, 1.12, 1.24) per item |
| s03 | clk1 | 0.15 s | mouse click / button press |
| s04 | pop1 | 0.23 s | card or bubble pop-in (vary rate .9-1.1, alternate pan) |
| s05 | clk2 | 0.16 s | soft click |
| s06 | rise | 0.57 s | short riser before a scene change |
| s07 | tap | 0.28 s | tiny tap for counters / words |
| s08 | blipT | 0.64 s | UI blip (use sparingly) |
| s09 | flut | 0.33 s | tile flip / paper flutter |
| s10 | typing | 1.92 s | keyboard typing for search-bar scenes |
| s11 | clk3 | 0.31 s | tick (play trimmed .07 s for a fast scan of list items) |
| s12 | blips | 0.64 s | multiple blips |
| s13 | swoosh | 0.51 s | transitions / cards sliding (rate 1.2-1.6, trim .25) |
| s14 | hit | 2.0 s | big hit for the end of a section (rare) |

RULES (from user feedback): calm and sparse; never the same sound on every item; the harsh sound that once played at 0:12-0:14 of the first video was REJECTED, use bell / pop / ding instead. No background music. `spec.png` / `sheet.jpg` are spectrograms of the reference.
`code/engine/sfx_synth.py` can also synthesize sounds from scratch (glass, whoosh, tick, bandnoise, sweep_noise ...).
