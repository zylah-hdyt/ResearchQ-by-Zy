prompt_pad.wav  = reference clip for ZipVoice voice cloning (0.4 s silence + 5.74 s of speech, 24 kHz).
prompt_text.txt = EXACT words spoken in prompt_pad.wav. They must match the audio, otherwise the first words of every generated line are dropped.
Use ONLY a voice you own or have permission to clone; label AI voice on YouTube ("altered or synthetic content").
