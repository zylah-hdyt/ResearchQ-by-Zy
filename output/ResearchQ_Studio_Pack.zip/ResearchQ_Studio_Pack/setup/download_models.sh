#!/usr/bin/env bash
# Downloads the speech models (NOT in the zip: ~3 GB). usage: bash download_models.sh <workspace_dir>   (workspace = $S in the scripts)
# GitHub release downloads sometimes 504: just re-run (curl -C - resumes).
set -e; S=${1:?workspace dir}; R=https://github.com/k2-fsa/sherpa-onnx/releases/download
mkdir -p $S/asr $S/tts/zv $S/tts/zvf
dl(){ curl -L -C - --retry 8 --retry-delay 5 -o "$2" "$1"; }
# Whisper turbo (ASR: forced alignment of words to the voice-over)
[ -d $S/asr/sherpa-onnx-whisper-turbo ] || { dl $R/asr-models/sherpa-onnx-whisper-turbo.tar.bz2 $S/asr/turbo.tar.bz2; tar xjf $S/asr/turbo.tar.bz2 -C $S/asr; }
# ZipVoice FULL model (voice cloning, best quality) + distilled int8 (only its lexicon.txt is needed) + vocoder
[ -d $S/tts/zvf/sherpa-onnx-zipvoice-zh-en-emilia ] || { dl $R/tts-models/sherpa-onnx-zipvoice-zh-en-emilia.tar.bz2 $S/tts/zvf/zv.tar.bz2; tar xjf $S/tts/zvf/zv.tar.bz2 -C $S/tts/zvf; }
[ -d $S/tts/zv/sherpa-onnx-zipvoice-distill-int8-zh-en-emilia ] || { dl $R/tts-models/sherpa-onnx-zipvoice-distill-int8-zh-en-emilia.tar.bz2 $S/tts/zv/d.tar.bz2; tar xjf $S/tts/zv/d.tar.bz2 -C $S/tts/zv; }
[ -f $S/tts/zv/vocos_24khz.onnx ] || dl $R/vocoder-models/vocos_24khz.onnx $S/tts/zv/vocos_24khz.onnx
echo done
