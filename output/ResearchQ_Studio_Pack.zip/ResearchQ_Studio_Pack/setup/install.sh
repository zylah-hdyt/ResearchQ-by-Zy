#!/usr/bin/env bash
# One-time setup for rendering videos from this pack. Needs: python3, node (>=18), ffmpeg already installed.
set -e
pip install sherpa-onnx soundfile scipy numpy pillow noisereduce pdfplumber
npm install playwright && npx playwright install chromium     # skip if Chromium + Playwright are already present (cloud sessions have them)
echo "ok. next: bash setup/download_models.sh <workspace_dir>"
