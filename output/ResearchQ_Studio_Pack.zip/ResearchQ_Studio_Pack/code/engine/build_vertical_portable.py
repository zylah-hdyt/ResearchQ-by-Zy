"""Portable HTML builder for the vertical (1080x1920) lip-sync template.
usage: python3 build_vertical_portable.py <pack_root> <project_dir> [words.json]
 - <project_dir> must contain: template.html (copy of code/templates/template.html, edited), work/words.json, lip/lip.json (from lipdata.py)
 - writes <project_dir>/video.html with fonts, textures, mascot poses, mouth sprites, logos and word timings embedded (no external files at render time).
 - topic-specific extras (e.g. {{HAIR}} book excerpts) are NOT handled here: replace those placeholders yourself or delete them from the template."""
import base64, json, sys, os
R, P = sys.argv[1], sys.argv[2]; WJ = sys.argv[3] if len(sys.argv) > 3 else 'words.json'
b = lambda p: base64.b64encode(open(p, 'rb').read()).decode()
h = open(f'{P}/template.html').read()
fonts = {'INTER500': 'inter-latin-500-normal', 'INTER600': 'inter-latin-600-normal', 'INTER700': 'inter-latin-700-normal', 'PJS800': 'plus-jakarta-sans-latin-800-normal',
         'JBM500': 'jetbrains-mono-latin-500-normal', 'IS400I': 'instrument-serif-latin-400-italic', 'ANTON': 'anton-latin-400-normal'}
for k, f in fonts.items(): h = h.replace('{{' + k + '}}', b(f'{R}/assets/fonts/{f}.woff2'))
h = h.replace('{{PAPER}}', 'data:image/jpeg;base64,' + b(f'{R}/assets/textures/paper.jpg'))
h = h.replace('{{GRAIN}}', json.dumps(['data:image/jpeg;base64,' + b(f'{R}/assets/textures/grain{i}.jpg') for i in range(8)]))
POS = ['m_open', 'm_thumb', 'm_think', 'm_point', 'm_warn', 'n_present', 'n_idea', 'n_shrug', 'n_wink']
h = h.replace('{{MOUTHS}}', json.dumps({n: 'data:image/png;base64,' + b(f'{R}/assets/mascot/mouths/mo_{n}.png') for n in POS}))
h = h.replace('{{MOUTHINFO}}', open(f'{R}/assets/mascot/mouth.json').read()).replace('{{LIP}}', open(f'{P}/lip/lip.json').read())
h = h.replace('{{MASCOT}}', json.dumps({n: 'data:image/png;base64,' + b(f'{R}/assets/mascot/poses/b_{n}.png') for n in POS}))
h = h.replace('{{LOGOS}}', json.dumps({n: 'data:image/png;base64,' + b(f'{R}/assets/logos/{n}.png') for n in ['tiktok', 'instagram', 'youtube']}))
h = h.replace('{{WORDS}}', json.dumps(json.load(open(f'{P}/work/{WJ}')), ensure_ascii=False))
if '{{HAIR}}' in h:  # topic-specific book excerpts: pass empty placeholders so the page still runs (scenes that show them stay blank)
    h = h.replace('{{HAIR}}', json.dumps({'cover': '', 'ex': '', 'q': '', 'qh': {'h': 120, 'w': 940, 'lines': []}})); print('note: {{HAIR}} replaced with empty data; edit the template / body.js if you do not need those scenes')
left = []
open(f'{P}/video.html', 'w').write(h); print('built', len(h) // 1024, 'KB', ('| unresolved: ' + ','.join(left)) if left else '')
