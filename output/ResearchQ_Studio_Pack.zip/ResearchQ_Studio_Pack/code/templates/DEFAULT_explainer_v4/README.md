# DEFAULT_explainer_v4 · pipeline lengkap (vertikal 1080x1920, 30 fps)

Gaya: lihat `docs/09_DEFAULT_STYLE_V4.md`. Contoh jadi: `reference/videos_480p/DEFAULT_v4_Parametrik_vs_Nonparametrik.mp4`.
`template.html` di folder ini adalah video Parametrik vs Nonparametrik (62 dtk) yang SUDAH JADI: untuk topik baru, pertahankan engine-nya dan tulis ulang adegannya.

Konvensi: `PK` = folder pack (`ResearchQ_Studio_Pack`), `PJ` = folder proyek baru, `T` = folder ini.

```bash
# 0. setup sekali
bash $PK/setup/install.sh && bash $PK/setup/download_models.sh    # ffmpeg, playwright, sherpa-onnx whisper turbo, noisereduce ...
mkdir -p $PJ/{work,lip,pdf} && cp $T/{template.html,recp.js,dumpev.js,snap.js} $PJ/

# 1. VO user (.m4a) -> bersih
ffmpeg -y -i vo.m4a -ac 1 -ar 48000 $PJ/work/src48.wav
python3 $PK/code/engine/vo_proc.py $PJ/work/src48.wav $PJ/work/vo_clean.wav $PJ/work/tmap.json
#   lalu EQ/de-ess/compress/normalize -15.5 LUFS -> $PJ/work/vo_final.wav (rantai ffmpeg: code/voice_tts/run_all.sh baris 3)
ffmpeg -y -i $PJ/work/vo_final.wav -ac 1 -ar 16000 $PJ/vf16.wav

# 2. kalimat + timing kata
#   tulis $PJ/sentences.json = [[start,end,"teks kalimat persis seperti diucapkan"], ...]  (dengarkan/ASR untuk batas kalimat)
python3 $PK/code/engine/align_words.py $S $PJ 0 4 &   # 3 rentang paralel -> words_0_4.json, words_4_7.json, ...
#   ($S = folder yang berisi asr/sherpa-onnx-whisper-turbo; lihat setup/download_models.sh)
#   cek: kata yang tidak diucapkan HARUS dihapus dari sentences.json, kalau tidak subtitle macet

# 3. lip-sync
python3 $PK/code/engine/lipdata.py $PJ            # -> $PJ/lip/lip.json

# 4. (opsional) artikel
python3 $T/pdf_pages.py artikel.pdf $PJ "kalimat yang dikutip" "kalimat kedua"   # -> pdf/pg*.jpg + kotak highlight

# 5. tulis adegan di $PJ/template.html (lihat "Peta template" di bawah), lalu build
python3 $T/build.py $PK $PJ                       # -> $PJ/video.html (semua di-embed)

# 6. cek frame kunci SEBELUM render penuh
node $PJ/snap.js shots 2,6,10,15,20,30,45,58      # -> $PJ/shots/*.jpg, lihat juga PAGEERR
#   buat contact sheet, LIHAT: tabrakan subtitle, teks terpotong, latar berganti, maskot

# 7. render penuh (4 worker paralel, bisa diulang: file yang sudah ada dilewati)
node $PJ/dumpev.js                                # -> work/events.json (berisi END)
N=$(python3 -c "import json,math;print(math.ceil(json.load(open('$PJ/work/events.json'))['END']*30))")
for i in 0 1 2 3; do SUB=full nohup node $PJ/recp.js $((N*i/4)) $((N*(i+1)/4)) > rw_$i.log 2>&1 & done

# 8. SFX + mix (SFX ±9 LU di bawah VO)
python3 $T/audio.py $PK $PJ                       # -> work/sfx.wav
#   GS = (LUFS_vo - 9) - LUFS_sfx ; amix VO + SFX*GS -> work/mix.wav (lihat docs/04)

# 9. encode + master
ffmpeg -y -framerate 30 -i $PJ/full/f%05d_0.jpg -i $PJ/work/mix.wav -map 0:v -map 1:a \
  -af loudnorm=I=-14.5:TP=-2:LRA=11 -c:v libx264 -preset slow -crf 19 -pix_fmt yuv420p \
  -c:a aac -b:a 192k -ar 48000 -movflags +faststart -shortest final.mp4
ffmpeg -i final.mp4 -af ebur128=peak=true -f null - 2>&1 | grep -E "I:|Peak:"   # target ±-14.8 LUFS, peak < -1.5

# 10. QA final: contact sheet 2 fps dari final.mp4 (fps=2,scale=180:320,tile=16x8), cek semua, baru kirim
```

## Peta template.html (yang dipertahankan vs ditulis ulang)
**Engine (pertahankan):**
- `pop()`, `draw()`, `op()` animasi dasar · `FW(kalimat,'kata')` = detik kata diucapkan · `SS/SE` awal/akhir kalimat
- `W1` jendela adegan per kalimat · `THEME` + `TCOL` + `THEMEF()` latar & circle-wipe · `#thdots` dot grid
- `SIG` + `BURSTF()` aksen Σ di pojok · `.bnum` angka bagian besar
- `rcam()` + `RCAM()` kamera halaman artikel (keyframe `[t, x, y, skala]` dalam piksel halaman 220 dpi; fokus di y≈320 dari atas frame: `cy = y_fokus + 120/skala`) · `.rw/.rd/.cov` frame + sampul
- `SUB()` subtitle kinetic tanpa kotak (KW = daftar kata kunci) · `MASC()` + `MWIN` + `PT` maskot: jendela tampil `[mulai, selesai, framing]` (BIG/SIDE/MID = talking head, STK/STKL = stiker) dan pose per waktu
- `window.SFXLIST` daftar event SFX (nama → `audio.py`)

**Ditulis ulang per topik:** isi `add(...)` (kartu, diagram, artikel), isi `SCN(t)`, `W1`, `THEME` per adegan, `KW`, `MWIN`/`PT`, `SFXLIST`.
