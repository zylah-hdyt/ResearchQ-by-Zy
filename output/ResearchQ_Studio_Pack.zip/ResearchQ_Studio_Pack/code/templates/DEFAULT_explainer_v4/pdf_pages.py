"""Article pages for the open-article camera + highlight boxes.
usage: python3 pdf_pages.py <article.pdf> <PROJECT> "phrase one" "phrase two" ...

- renders every page at 220 dpi -> PROJECT/pdf/pg1.jpg, pg2.jpg, ... (1870x2420 for Letter size)
- for each phrase prints the page number and the line boxes [x, y, w, h] in page pixels,
  ready to paste into the template (reader highlights) and the camera target (centre of the boxes).
Needs: pdftoppm (poppler-utils), pdfplumber, Pillow.
"""
import sys, os, re, subprocess, glob
import pdfplumber
from PIL import Image
pdf, PJ = sys.argv[1:3]; phrases = sys.argv[3:]
DPI = 220; k = DPI / 72
out = f'{PJ}/pdf'; os.makedirs(out, exist_ok=True)
subprocess.run(['pdftoppm', '-r', str(DPI), '-png', pdf, f'{out}/_p'], check=True)
for f in sorted(glob.glob(f'{out}/_p-*.png')):
    n = int(re.findall(r'-(\d+)\.png$', f)[0])
    Image.open(f).convert('RGB').save(f'{out}/pg{n}.jpg', quality=88); os.remove(f)
norm = lambda w: re.sub(r'[^a-z0-9]', '', w.lower())
with pdfplumber.open(pdf) as doc:
    for ph in phrases:
        target = [norm(w) for w in ph.split() if norm(w)]
        for pi, page in enumerate(doc.pages, 1):
            ws = page.extract_words(use_text_flow=True)
            nw = [norm(w['text']) for w in ws]
            for i in range(len(ws)):
                if nw[i:i + len(target)] == target:
                    lines = {}
                    for w in ws[i:i + len(target)]:
                        key = round(w['top'] / 3)
                        L = lines.setdefault(key, [w['x0'], w['top'], w['x1'], w['bottom']])
                        L[0] = min(L[0], w['x0']); L[2] = max(L[2], w['x1']); L[3] = max(L[3], w['bottom'])
                    boxes = [[round(a * k), round(t * k) - 4, round((c - a) * k), round((d - t) * k) + 8] for a, t, c, d in lines.values()]
                    print(f'"{ph}" -> page {pi}: boxes {boxes}')
                    break
print('pages saved to', out)
