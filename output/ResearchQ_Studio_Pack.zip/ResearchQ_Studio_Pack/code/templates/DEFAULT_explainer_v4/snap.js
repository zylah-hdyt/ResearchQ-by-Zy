const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const out=__dirname+'/'+process.argv[2];fs.mkdirSync(out,{recursive:true});const b=await chromium.launch();const p=await b.newPage({viewport:{width:1080,height:1920}});
p.on('pageerror',e=>console.log('PAGEERR',String(e).slice(0,300)));await p.goto('file://'+__dirname+'/video.html?render');await p.evaluate(()=>document.fonts.ready);
for(const t of process.argv[3].split(',').map(Number)){await p.evaluate(t=>render(t),t);await p.screenshot({path:`${out}/t_${t.toFixed(2).padStart(6,'0')}.jpg`,type:'jpeg',quality:70})}await b.close()})();
