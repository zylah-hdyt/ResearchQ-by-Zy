"""Build PROJECT/video.html from template.html (default v4 style).
usage: python3 build.py <PACK_ROOT> <PROJECT>

Needs in PROJECT/:
  template.html          (copy of this folder's template, scenes rewritten for the new topic)
  words_*.json  or work/words.json   (word timings from align_words.py: [{s,e,words:[[w,t],...]},...])
  lip/lip.json           (from code/engine/lipdata.py)
Optional:
  pdf/excerpts.json + pdf/ex_<key>.png   (cropped excerpts with highlight boxes)
  pdf/pg<N>.jpg                          (full article pages @220 dpi for the open-article camera, made by pdf_pages.py)
"""
import base64, json, sys, glob, os
PK, PJ = sys.argv[1:3]
b = lambda p: base64.b64encode(open(p, 'rb').read()).decode()
h = open(f'{PJ}/template.html').read()
F = f'{PK}/assets/fonts'
for k, f in {'INTER500': 'inter-latin-500-normal.woff2', 'INTER600': 'inter-latin-600-normal.woff2',
             'INTER700': 'inter-latin-700-normal.woff2', 'PJS800': 'plus-jakarta-sans-latin-800-normal.woff2'}.items():
    h = h.replace('{{' + k + '}}', b(f'{F}/{f}'))
POS = ['m_open', 'm_thumb', 'm_think', 'm_point', 'm_warn', 'n_present', 'n_idea', 'n_shrug', 'n_wink']
M = f'{PK}/assets/mascot'
h = h.replace('{{MASCOT}}', json.dumps({n: 'data:image/png;base64,' + b(f'{M}/poses/b_{n}.png') for n in POS}))
h = h.replace('{{MOUTHS}}', json.dumps({n: 'data:image/png;base64,' + b(f'{M}/mouths/mo_{n}.png') for n in POS}))
h = h.replace('{{MOUTHINFO}}', open(f'{M}/mouth.json').read()).replace('{{LIP}}', open(f'{PJ}/lip/lip.json').read())
W = []
parts = sorted(glob.glob(f'{PJ}/words_*_*.json'), key=lambda f: int(f.split('_')[-2]))
if parts:
    for f in parts: W += json.load(open(f))
else:
    W = json.load(open(f'{PJ}/work/words.json'))
ex = f'{PJ}/pdf/excerpts.json'
EX = open(ex).read() if os.path.exists(ex) else '{}'
IMG = {}
for k in json.loads(EX):
    p = f'{PJ}/pdf/ex_{k}.png'
    if os.path.exists(p): IMG[k] = 'data:image/png;base64,' + b(p)
for p in sorted(glob.glob(f'{PJ}/pdf/pg*.jpg')):
    IMG[os.path.basename(p)[:-4]] = 'data:image/jpeg;base64,' + b(p)
h = h.replace('{{EXCERPTS}}', EX).replace('{{IMG}}', json.dumps(IMG))
h = h.replace('{{WORDS}}', json.dumps(W, ensure_ascii=False))
open(f'{PJ}/video.html', 'w').write(h)
print('built', len(h) // 1024, 'KB, sentences', len(W), 'images', list(IMG))
